<?php
/* Force plugin files to be included in the plugin */
if ( ! defined( 'ECP1_PLUGIN' ) ) {
	die( 'Cannot use the Every Calendar +1 plugin files outside the plugin!' );
}
// Don't close the php interpreter
/*?>*/
