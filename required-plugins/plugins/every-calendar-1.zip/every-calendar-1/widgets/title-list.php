<?php
/**
 * Every Calendar +1 Plugin Widget: List of event titles
 */

// Make sure we're included from within the plugin
require( ECP1_DIR . '/includes/check-ecp1-defined.php' );

// Also we need the plugin functions
require_once( ECP1_DIR . '/functions.php' );

/**
 * Widget for listing events by date
 *
 */
class ECP1_TitleListWidget extends WP_Widget {
	
	/**
	 * Static constants for defining sorting order
	 */
	const SORT_NEXT_FIRST = 1;
	const SORT_LAST_FIRST = 2;

	/**
	 * Widget constructor
	 * @see WP_Widget::WP_Widget
	 */
	function ECP1_TitleListWidget() {
		// Just call the parent with appropriate attributes for this class
		parent::WP_Widget('ecp1_titlelistwidget', 'EveryCal+1 Event Title List', array(
			'description' => 'EveryCal+1 Event Title List - An ordered list of event titles up to given number'
		));
	}


	/**
	 * Display the widget
	 * @see WP_Widget:widget
	 *
	 * @param $args Array of widget arguments from WordPress
	 * @param $instance Array of widget configured settings from admin
	 */
	function widget( $args, $instance ) {
		extract( $args, EXTR_SKIP );
		echo $before_widget; // from $args
		$title = empty($instance['title']) ? '&nbsp;' : apply_filters('widget_title', $instance['title']);
		if ( !empty( $title ) ) { echo $before_title . $title . $after_title; };

		// Get an array of the events 
		$cal = get_post( $instance['calendar'], OBJECT );
		if ( is_null( $cal ) ) {
			printf( '<p>%s</p>', __( 'Could not load calendar!' ) );
			return;
		}

		$include_externals = array_key_exists( 'include_externals', $instance ) && 1 == $instance['include_externals'];
		$lookahead = 365;
		$events = EveryCal_Scheduler::GetEventList( $cal->ID, $lookahead, $include_externals );

		if ( count( $events ) > 0 ) {
			// Sort the array and if over the item limit truncate it
			if ( self::SORT_NEXT_FIRST == $instance['sort_order'] )
				usort( $events, 'next_first' );
			if ( self::SORT_LAST_FIRST == $instance['sort_order'] )
				usort( $events, 'last_first' );
			if ( count( $events ) >=  $instance['count'] )
				$events = array_slice( $events, 0, $instance['count'] );

			// Loop over the events and display them in a list
			printf( '<ol class="%s">', esc_attr( $instance['list_class'] ) );
			foreach( $events as $event ) {
				$tmpl = '<li class="%1$s"><span>%2$s:</span> <a href="%4$s" title="Visit event page">%3$s</a></li>';
				if ( is_null( $event['link'] ) )
					$tmpl = '<li class="%1$s"><span>%2$s:</span> %3$s</li>';
				printf( $tmpl, esc_attr( $instance['item_class'] ),
					$event['start']->format( 'j/M' ), $event['title'], $event['link'] );
			}
			print( '</ol>' );
		} else {
			printf( '<p class="%s">%s</p>', esc_attr( $instance['list_class'] ), 
				empty( $instance['none_msg'] ) ? __( 'No events scheduled' ) : $instance['none_msg'] );
		}
		echo $after_widget; // from $args
	}

	/**
	 * Called to update/save the widget settings
	 * @see WP_Widget::update
	 *
	 * The following parameters are POSTED using the form() below
	 *  calendar: The EveryCal calendar for events
	 *  title: The widget title text
	 *  none_msg: Message to display when no events listed
	 *  count: The number of events to display
	 *  sort_order: Newest first or oldest first
	 *  list_class: CSS Class for list element
	 *  item_class: CSS Class for list item elements
	 *  include_externals: 0|1 if should include external events
	 *
	 * @param $new_instance New instance of values from the form
	 * @param $old_instance Previous instance values
	 * @return Complete set of values for the widget 
	 */
	function update( $new_instance, $old_instance ) {
		$ins = $old_instance;
		$cal_new = intval( $new_instance['calendar'] );
		// Ensure the calendar exists
		$cals = get_posts( array( 'post_type' => 'ecp1_calendar', 'include' => array( $cal_new ) ) );
		if ( count( $cals ) > 0 )
			$ins['calendar'] = $cal_new;
		$ins['title'] = sanitize_text_field( $new_instance['title'] );
		$ins['none_msg'] = sanitize_text_field( $new_instance['none_msg'] );
		$ins['count'] = intval( $new_instance['count'] );
		$ins['sort_order'] = intval( $new_instance['sort_order'] );
		$ins['list_class'] = sanitize_text_field( $new_instance['list_class'] );
		$ins['item_class'] = sanitize_text_field( $new_instance['item_class'] );
		$ins['include_externals'] = intval( $new_instance['include_externals'] );
		return $ins;
	}

	/**
	 * Render a form for configuring the widget
	 * @see WP_Widget::form
	 *
	 * See update() for a description of the form fields.
	 *
	 * @param $instance Current widget settings
	 */
	function form( $instance ) {
		// Set some defaults if this is a new widget
		$defaults = array(
			'calendar' => 0,
			'title' => __( 'Upcoming events' ),
			'none_msg' => __( 'No events scheduled' ),
			'count' => 5,
			'list_class' => 'ecp1_list',
			'item_class' => 'ecp1_list_item',
			'sort_order' => self::SORT_NEXT_FIRST,
			'include_externals' => 0,
		);

		// Parse the arguments in instance and merge with defaults
		$instance = wp_parse_args( (array) $instance, $defaults );

		// Get a list of all the valid calendars
		$cal_options = array();
		$cals = _ecp1_current_user_calendars();
		foreach( $cals as $cal )
			$cal_options[$cal->ID] = esc_html( $cal->post_title );

		// Create the form for the fields
		$fields = array(
			'calendar' => array( 'label' => __( 'Calendar' ), 'type' => 'select', 'options' => $cal_options ),
			'title' => array( 'label' => __( 'Title' ), 'type' => 'text', 'length' => 100 ),
			'none_msg' => array( 'label' => __( 'No events message' ), 'type' => 'text', 'length' => 100 ),
			'count' => array( 'label' => __( 'Number of events' ), 'type' => 'text', 'length' => 2 ),
			'sort_order' => array( 'label' => __( 'Order' ), 'type' => 'select', 'options' => array(
				self::SORT_NEXT_FIRST => __( 'Next event first' ),
				self::SORT_LAST_FIRST => __( 'Next event last' ) ) ),
			'list_class' => array( 'label' => __( 'Ordered list CSS class' ), 'type' => 'text', 'length' => 20 ),
			'item_class' => array( 'label' => __( 'List item CSS class' ), 'type' => 'text', 'length' => 20 ),
			'include_externals' => array( 'label' => __( 'Include external calendar events?' ), 'type' => 'select',
				'options' => array( 0 => __( 'No' ), 1 => __( 'Yes' ) ) ),
		);
		print( '<ul class="ecp1_admin_form_list">' );
		foreach( $fields as $key=>$dtl ) {
			$id = $this->get_field_id( $key );
			$name = $this->get_field_name( $key );
			printf( '<li><label for="%s">%s</label>', esc_attr( $id ), esc_html( $dtl['label'] ) );
			if ( $dtl['type'] == 'text' ) {
				printf( '<input type="text" maxlength="%d" id="%s" name="%s" value="%s" />',
					array_key_exists( 'length', $dtl ) ? $dtl['length'] : 255,
					esc_attr( $id ), esc_attr( $name ), esc_attr( $instance[$key] ) );
			} else if ( $dtl['type'] == 'select' ) {
				printf( '<select id="%s" name="%s">', esc_attr( $id ), esc_attr( $name ) );
				foreach( $dtl['options'] as $v=>$l )
					printf( '<option value="%s"%s>%s</option>', $v, intval( $instance[$key] ) == intval( $v ) ? ' selected="selected"' : '', $l );
				print( '</select>' );
			}
			print( '</li>' );
		}
		print( '</ul>' );
		printf( '<p>%s</p>', __( 'Note: this list will only include events occuring in the next 12 months.' ) );
	}

}

// Don't close the php interpreter
/*?>*/
