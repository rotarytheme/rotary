=== N-Media MailChimp Subscription ===
Contributors: nmedia
Donate link: http://www.najeebmedia.com/donate/
Tags: mailchimp, newsletters subscription, email subscription, email form
Requires at least: 3.0
Tested up to: 4.2
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin pulls all List, variables and groups from Mailchimp account then allow you to create subscription form using Form Wizard Tool.

== Description ==

Mailchimp Subscription is simple plugin to render Subscription Forms on your Wordpress Blog/Site. It pulls all Mailchimp Lists from your Account and allow admin to
create Forms using Vars and Interest Group with Awesome <strong>AngularJS</strong> based Admin panel.

= Features =
* <strong>Create list variables</strong>
* <strong>Create list Interest Groups</strong>
* Visual form designer
* Groups choices on front end
* Create unlimited subscription forms using Form Wizard Tool
* Use shortcodes in Post/Pages
* Widget support
* Pre append text on Widgets
* Write your own Style/CSS
* Multilingual Support
* Create Popups
* AngularJS Based Admin


= How it works (Pro Version) =
[vimeo https://vimeo.com/122874502]

= PRO Version =
Now you can create Mailchimp Campaigns using Wordpress Posts/Pages. In few click Newsletter is ready to send to any List.
* Create Campaigns using Post/Pages contents
* Create your own Template with Custom Header (image, HTML) and Footer (HTML)
* Test campaigns before you send it.
* Campaign graphical reports
* Delete campaigns

[More detail](http://najeebmedia.com/wordpress-plugin/wordpress-mailchimp-subscription-form-create-manage-campaigns/)


== Installation ==

1. Upload `nm_mailchimp` directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Once Plugin is activated, Set the MailChimp API key from `Admin / MailChimp Campaign`

== Frequently Asked Questions ==

= Can I use this widget more then one places in same site? =

Yes, you can. It is multi instance supported.

= How to get API Keys =

You can see this tutorial to get API Key from MailChimp: [Click here](http://www.najeebmedia.com/where-can-i-find-my-mailchimp-api-key/)


== Screenshots ==

1. Enter Mailchimp API Key from `Admin / N-Media MailChimp / General Settings`
2. Listing all your Mailchimp Lists (Variables, Groups of selected List)	
3. Pasting shortcode on page/post to render form
4. Form rendered on page/post
5. Widget

== Changelog ==
= 4.4 24 June, 2015 =
* BUG Fixed: Mailchimp class name conflict removed

= 4.4 21 June, 2015 =
* Feature Added: Multiple posts can be used as campaign content.
* Feature Added: Custom posts can be used as campaign content.
* Feature Added: Post excerpt option added.
* Feature Added: Featured image of posts can also be used.
* Bug Fixed: Loading screen added when lists are being pulled.
* Enhanced UI button for creating new Campaign.

= 4.3 6 June, 2015 =
* Bug Fixed: Visual form designer not working with settings, not it.
* Four languages translations added, Duetch, French, Spanish

= 4.2 3 June, 2015 =
* Added visual form designer
* Show groups list on front end.
* Bug fixed: when no API Key provided it broke the site, now it is fixed.
= 4.1 =
* Error handling if subscriber is already exists
* remove Notices
= 4.0 =
* AngularJS based Admin
* Popup Subscription Form



== Upgrade Notice ==