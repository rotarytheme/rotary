<?php

class Mailchimp_Neapolitan {
    public function __construct(NM_Mailchimp $master) {
        $this->master = $master;
    }

}


