<?php
/**
 * delete options, tables or anything else
 * if required
 */
delete_option( 'nm_mailchimp_form_settings' );
?>